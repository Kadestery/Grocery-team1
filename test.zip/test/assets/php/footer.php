<footer>
    <div class="footer">
        <div class="team">
            <ul>
                <h1>Our team</h1>
                <li>
                    <a target="_blank" href="https://www.linkedin.com/in/ali-fetanat-42216521b/">Ali Fetanat</a>
                </li>
                <li>
                    <a target="_blank" href="">Elliot Vinet</a>
                </li>
                <li>
                    <a target="_blank" href="https://www.linkedin.com/in/gabriel-dubois-soen/">Gabriel Dubois</a>
                </li>
                <li>
                    <a target="_blank" href="">Kade Keating</a>
                </li>
                <li>
                    <a target="_blank" href="">Minh Thuan Huynh</a>
                </li>
                <li>
                    <a target="_blank" href="https://ca.linkedin.com/in/xavier-guertin-b896a71a6">Xavier Guertin</a>
                </li>
            </ul>
        </div>
        <div class="jobs">
            <h1>Jobs</h1>
            <ul>
                <li>
                    <p>Jobs in stores</p>
                </li>
                <li>
                    <p>Careers at head office</p>
                </li>
            </ul>
        </div>
        <div class="customer">
            <h1>Customer service</h1>
            <ul>
                <li>
                    <p>Contact us</p>
                </li>
                <li>
                    <p>Terms and conditions</p>
                </li>
                <li>
                    <p>Privacy policy</p>
                </li>
                <li>
                    <p>Find a store</p>
                </li>
                <li>
                    <p>FAQ</p>
                </li>
            </ul>
        </div>
    </div>
    <p class="copyright">&copy; 2022. all rights reserved</p>

</footer>